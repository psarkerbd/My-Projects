<!doctype html>
<html>

<head> 

 <title> Ask a Question </title>
 <meta charset="utf-8" />
 <meta name="auhtor" content="pranta" />
 <link rel="stylesheet" type="text/css" href="css/authorcss/style.css" />
  <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/blog-home.css" rel="stylesheet">

</head>

<body>

<p class = "navbar-brand" onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Author</p>

<div id="id01" class="modal">
  
  <form class="modal-content animate" action="/action_page.php">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Author">&times;</span>
      <img src="authorimg/author.png" alt="Author's Photo" class="avatar">
    </div>

    <div class="design">
      
		<p> Pranta Sarker </p>
		<p> Dept. of CSE </p>
		<p> North East University Bangladesh, Sylhet </p>
	  
    </div>
	
  </form>
</div>

<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it



window.onclick = function(event) {
	
	
	if (event.target == modal) {
        modal.style.display = "none";
		
    }
}
</script>

</body>
</html>
