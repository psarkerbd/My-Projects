<!doctype html>
<html lang="en">

<head>

    <?php include 'include/onhead.php'  ?>

</head>

<body>

		<?php include 'include/navigation.php' ?>
	
		<?php include 'include/content.php' ?>

		<?php include 'include/sidebar.php' ?>

           
       <?php include 'include/footer.php' ?>

</body>

</html>
